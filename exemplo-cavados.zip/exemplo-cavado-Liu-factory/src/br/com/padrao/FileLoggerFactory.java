/**
* Class gerada automaticamente pelo sistema de refatoração - Factory 
* @author - Thyago Henrique Pacher
 *@since 2 de Maio de 2018
 */
public class FileLoggerFactory extends LoggerFactory {

    public Logger createLogger() {
        return new FileLogger();
    }
}
