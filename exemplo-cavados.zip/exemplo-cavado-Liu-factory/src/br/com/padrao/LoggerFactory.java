package br.com.padrao;

/**
 * exemplo cavado padr?o para aplicar Factory
 */
public class LoggerFactory{

    public Logger createLogger(char type) {
        if(type == 'D'){
			return new DatabaseLogger();
		}else if(type == 'F'){
			return new FileLogger();
		}else{
			return null;	
		}
    }
}
