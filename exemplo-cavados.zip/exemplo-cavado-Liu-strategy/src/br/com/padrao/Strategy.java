public abstract class Strategy {

    public double calculate(double price) {
    }
}
