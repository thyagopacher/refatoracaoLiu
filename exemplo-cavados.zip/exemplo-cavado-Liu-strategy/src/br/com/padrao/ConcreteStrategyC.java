/**
* Class gerada automaticamente pelo sistema de refatoração
* @author - Thyago Henrique Pacher
 *@since 30 de Abril de 2018
 */
public class ConcreteStrategyC extends Strategy {

    public double calculate(double price) {
        return price - 10;
    }
}
